import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.cobrinha.filha',
  appName: 'Cobrinha da Filha',
  webDir: 'dist'
};

export default config;
