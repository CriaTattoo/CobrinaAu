#!/bin/bash

# Script para buildar o APK do jogo da cobrinha
# Uso: ./build-apk.sh

set -e

echo "🐍 Cobrinha da Filha - Build Script"
echo "===================================="
echo ""

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Verificar se o Node.js está instalado
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js não encontrado!${NC}"
    echo "Por favor, instale o Node.js 20+ de https://nodejs.org/"
    exit 1
fi

echo -e "${GREEN}✓ Node.js encontrado${NC}"

# Verificar versão do Node
NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo -e "${YELLOW}⚠️  Node.js versão $NODE_VERSION detectado. Recomendado: 18+${NC}"
fi

# Verificar Java
if ! command -v java &> /dev/null; then
    echo -e "${RED}❌ Java não encontrado!${NC}"
    echo "Por favor, instale o Java JDK 17+"
    exit 1
fi

echo -e "${GREEN}✓ Java encontrado${NC}"

# Verificar ANDROID_HOME
if [ -z "$ANDROID_HOME" ]; then
    echo -e "${YELLOW}⚠️  ANDROID_HOME não configurado${NC}"
    echo "Procurando por Android SDK..."
    
    # Procurar em locais comuns
    if [ -d "$HOME/Android/Sdk" ]; then
        export ANDROID_HOME="$HOME/Android/Sdk"
        echo -e "${GREEN}✓ Android SDK encontrado em: $ANDROID_HOME${NC}"
    elif [ -d "/usr/lib/android-sdk" ]; then
        export ANDROID_HOME="/usr/lib/android-sdk"
        echo -e "${GREEN}✓ Android SDK encontrado em: $ANDROID_HOME${NC}"
    else
        echo -e "${RED}❌ Android SDK não encontrado!${NC}"
        echo ""
        echo "Opções:"
        echo "1. Instale o Android Studio: https://developer.android.com/studio"
        echo "2. Ou defina ANDROID_HOME apontando para seu SDK"
        echo ""
        echo "Para instalar automaticamente, execute:"
        echo "  mkdir -p ~/Android/Sdk"
        echo "  cd ~/Android/Sdk"
        echo "  wget https://dl.google.com/android/repository/commandlinetools-linux-9477386_latest.zip"
        echo "  unzip commandlinetools-linux-9477386_latest.zip"
        echo "  mkdir -p cmdline-tools/latest"
        echo "  mv cmdline-tools/* cmdline-tools/latest/ 2>/dev/null || true"
        echo "  export ANDROID_HOME=~/Android/Sdk"
        echo "  export PATH=\$PATH:\$ANDROID_HOME/cmdline-tools/latest/bin"
        echo "  yes | sdkmanager --licenses"
        echo "  sdkmanager 'platform-tools' 'platforms;android-34' 'build-tools;34.0.0'"
        exit 1
    fi
fi

echo ""
echo "📦 Instalando dependências..."
npm install

echo ""
echo "🔨 Buildando app web..."
npm run build

echo ""
echo "📱 Sincronizando com Android..."
node ./node_modules/@capacitor/cli/bin/capacitor sync android

echo ""
echo "🔧 Buildando APK..."
cd android
chmod +x gradlew
./gradlew assembleDebug

echo ""
echo -e "${GREEN}====================================${NC}"
echo -e "${GREEN}✅ Build completo!${NC}"
echo ""
echo "APK gerado em:"
echo "  android/app/build/outputs/apk/debug/app-debug.apk"
echo ""
echo "Para instalar no celular:"
echo "  adb install android/app/build/outputs/apk/debug/app-debug.apk"
echo ""
echo -e "${GREEN}🎮 Divirta-se!${NC}"
