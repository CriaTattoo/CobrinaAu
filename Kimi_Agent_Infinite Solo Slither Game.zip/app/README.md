# 🐍 Cobrinha da Filha

Um jogo da cobrinha estilo Slither.io com **jogabilidade infinita** - a cobrinha nunca morre! Perfeito para crianças que querem se divertir sem se frustrar.

## ✨ Características

- 🎮 **Jogabilidade Infinita**: A cobrinha nunca morre, mesmo batendo nas paredes ou em si mesma!
- 🌈 **Visual Colorido**: Cores vibrantes e efeitos brilhantes
- 📱 **Controles Touch**: Arraste o dedo na tela para mover a cobrinha
- ⌨️ **Controles de Teclado**: Também funciona com as setas do teclado
- 🍎 **Comida Brilhante**: Bolinhas coloridas que fazem a cobrinha crescer
- ✨ **Efeitos de Partículas**: Explosões de luz ao comer

## 🚀 Como Jogar

1. Toque na tela ou use as setas para mover a cobrinha
2. Coma as bolinhas coloridas para ganhar pontos
3. A cobrinha cresce a cada comida
4. Divirta-se sem medo de perder!

## 📲 Instalação no Android

### Opção 1: GitHub Actions (Automático)

1. Faça push deste código para um repositório no GitHub
2. O GitHub Actions vai automaticamente buildar o APK
3. Baixe o APK da aba "Actions" ou "Releases"

### Opção 2: Android Studio (Manual)

1. Instale o [Android Studio](https://developer.android.com/studio)
2. Clone este repositório
3. Abra a pasta `android` no Android Studio
4. Aguarde o Gradle sincronizar
5. Vá em **Build > Build Bundle(s) / APK(s) > Build APK(s)**
6. O APK será gerado em `android/app/build/outputs/apk/debug/`

### Opção 3: Linha de Comando (Linux/Mac)

```bash
# Instale as dependências
npm install

# Build o app web
npm run build

# Sincronize com o Android
npx cap sync android

# Entre na pasta android e build
cd android
./gradlew assembleDebug

# O APK estará em:
# android/app/build/outputs/apk/debug/app-debug.apk
```

## 🛠️ Desenvolvimento

```bash
# Instalar dependências
npm install

# Rodar em modo desenvolvimento
npm run dev

# Build para produção
npm run build
```

## 📝 Tecnologias

- React + TypeScript
- Canvas API
- Capacitor (para Android)
- Vite

## 💝 Para a Princesa

Este jogo foi feito com muito carinho para uma princesa muito especial que merece diversão sem limites! 🌟

---

**Nota**: Este é um jogo offline, não requer internet para jogar!
