import { useEffect, useRef, useState, useCallback } from 'react';
import './App.css';

interface Point {
  x: number;
  y: number;
}

interface Food {
  x: number;
  y: number;
  color: string;
  glowColor: string;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
}

const COLORS = [
  { body: '#FF6B6B', glow: '#FF8E8E' },
  { body: '#4ECDC4', glow: '#6EDDD6' },
  { body: '#45B7D1', glow: '#67C5DB' },
  { body: '#96CEB4', glow: '#A8D6C1' },
  { body: '#FECA57', glow: '#FED470' },
  { body: '#FF9FF3', glow: '#FFB3F5' },
  { body: '#54A0FF', glow: '#76B3FF' },
  { body: '#48DBFB', glow: '#6AE4FC' },
];

const FOOD_COLORS = [
  { main: '#FF6B6B', glow: '#FF8E8E' },
  { main: '#4ECDC4', glow: '#6EDDD6' },
  { main: '#FECA57', glow: '#FED470' },
  { main: '#FF9FF3', glow: '#FFB3F5' },
  { main: '#54A0FF', glow: '#76B3FF' },
];

function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number | null>(null);
  const snakeRef = useRef<Point[]>([]);
  const directionRef = useRef<Point>({ x: 1, y: 0 });
  const targetDirectionRef = useRef<Point>({ x: 1, y: 0 });
  const foodRef = useRef<Food[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const scoreRef = useRef(0);
  const snakeColorRef = useRef(COLORS[0]);
  const touchStartRef = useRef<Point | null>(null);
  const gameAreaRef = useRef<HTMLDivElement>(null);
  
  const [score, setScore] = useState(0);
  const [showStartScreen, setShowStartScreen] = useState(true);
  const [canvasSize, setCanvasSize] = useState({ width: 800, height: 600 });

  // Initialize canvas size based on screen
  useEffect(() => {
    const updateSize = () => {
      const isMobile = window.innerWidth < 768;
      const width = isMobile ? window.innerWidth - 20 : Math.min(window.innerWidth - 40, 1000);
      const height = isMobile ? window.innerHeight - 100 : Math.min(window.innerHeight - 100, 700);
      setCanvasSize({ width, height });
    };
    
    updateSize();
    window.addEventListener('resize', updateSize);
    return () => window.removeEventListener('resize', updateSize);
  }, []);

  const createFood = useCallback((): Food => {
    const colorSet = FOOD_COLORS[Math.floor(Math.random() * FOOD_COLORS.length)];
    return {
      x: Math.random() * (canvasSize.width - 40) + 20,
      y: Math.random() * (canvasSize.height - 40) + 20,
      color: colorSet.main,
      glowColor: colorSet.glow,
    };
  }, [canvasSize]);

  const createParticles = useCallback((x: number, y: number, color: string) => {
    for (let i = 0; i < 8; i++) {
      const angle = (Math.PI * 2 * i) / 8;
      const speed = 2 + Math.random() * 3;
      particlesRef.current.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: 1,
        maxLife: 1,
        color,
        size: 3 + Math.random() * 4,
      });
    }
  }, []);

  const initGame = useCallback(() => {
    const centerX = canvasSize.width / 2;
    const centerY = canvasSize.height / 2;
    
    snakeRef.current = [
      { x: centerX, y: centerY },
      { x: centerX - 10, y: centerY },
      { x: centerX - 20, y: centerY },
      { x: centerX - 30, y: centerY },
      { x: centerX - 40, y: centerY },
    ];
    
    directionRef.current = { x: 1, y: 0 };
    targetDirectionRef.current = { x: 1, y: 0 };
    scoreRef.current = 0;
    setScore(0);
    
    // Create initial food
    foodRef.current = [];
    for (let i = 0; i < 5; i++) {
      foodRef.current.push(createFood());
    }
    
    particlesRef.current = [];
    snakeColorRef.current = COLORS[Math.floor(Math.random() * COLORS.length)];
  }, [canvasSize, createFood]);

  // Handle keyboard input
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (showStartScreen) return;
      
      const keyMap: { [key: string]: Point } = {
        ArrowUp: { x: 0, y: -1 },
        ArrowDown: { x: 0, y: 1 },
        ArrowLeft: { x: -1, y: 0 },
        ArrowRight: { x: 1, y: 0 },
        w: { x: 0, y: -1 },
        s: { x: 0, y: 1 },
        a: { x: -1, y: 0 },
        d: { x: 1, y: 0 },
      };

      if (keyMap[e.key]) {
        e.preventDefault();
        const newDir = keyMap[e.key];
        const currentDir = directionRef.current;
        
        // Prevent 180-degree turns
        if (newDir.x !== -currentDir.x || newDir.y !== -currentDir.y) {
          targetDirectionRef.current = newDir;
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [showStartScreen]);

  // Handle touch controls
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    const touch = e.touches[0];
    touchStartRef.current = { x: touch.clientX, y: touch.clientY };
  }, []);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (!touchStartRef.current || showStartScreen) return;
    
    const touch = e.touches[0];
    const dx = touch.clientX - touchStartRef.current.x;
    const dy = touch.clientY - touchStartRef.current.y;
    
    const minSwipe = 30;
    
    if (Math.abs(dx) > minSwipe || Math.abs(dy) > minSwipe) {
      let newDir: Point;
      
      if (Math.abs(dx) > Math.abs(dy)) {
        newDir = dx > 0 ? { x: 1, y: 0 } : { x: -1, y: 0 };
      } else {
        newDir = dy > 0 ? { x: 0, y: 1 } : { x: 0, y: -1 };
      }
      
      const currentDir = directionRef.current;
      if (newDir.x !== -currentDir.x || newDir.y !== -currentDir.y) {
        targetDirectionRef.current = newDir;
      }
      
      touchStartRef.current = { x: touch.clientX, y: touch.clientY };
    }
  }, [showStartScreen]);

  const handleTouchEnd = useCallback(() => {
    touchStartRef.current = null;
  }, []);

  // Game loop
  useEffect(() => {
    if (showStartScreen) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const gameLoop = () => {
      // Smooth direction change
      const targetDir = targetDirectionRef.current;
      const currentDir = directionRef.current;
      
      if (targetDir.x !== currentDir.x || targetDir.y !== currentDir.y) {
        directionRef.current = targetDir;
      }

      // Update snake
      const snake = snakeRef.current;
      const dir = directionRef.current;
      const speed = 3;
      
      const head = { ...snake[0] };
      head.x += dir.x * speed;
      head.y += dir.y * speed;

      // INFINITE GAMEPLAY: Wrap around edges instead of dying
      if (head.x < 0) head.x = canvasSize.width;
      if (head.x > canvasSize.width) head.x = 0;
      if (head.y < 0) head.y = canvasSize.height;
      if (head.y > canvasSize.height) head.y = 0;

      snake.unshift(head);

      // Check food collision
      let ateFood = false;
      foodRef.current = foodRef.current.filter((food) => {
        const dx = head.x - food.x;
        const dy = head.y - food.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if (distance < 25) {
          ateFood = true;
          scoreRef.current += 10;
          setScore(scoreRef.current);
          createParticles(food.x, food.y, food.color);
          
          // Add new food
          setTimeout(() => {
            foodRef.current.push(createFood());
          }, 500);
          
          return false;
        }
        return true;
      });

      if (!ateFood) {
        snake.pop();
      } else {
        // Grow more segments when eating
        for (let i = 0; i < 2; i++) {
          const tail = snake[snake.length - 1];
          snake.push({ ...tail });
        }
      }

      // INFINITE GAMEPLAY: No self-collision check! The snake can pass through itself

      // Update particles
      particlesRef.current = particlesRef.current.filter((p) => {
        p.x += p.vx;
        p.y += p.vy;
        p.life -= 0.03;
        p.vx *= 0.95;
        p.vy *= 0.95;
        return p.life > 0;
      });

      // Clear canvas
      ctx.fillStyle = '#1a1a2e';
      ctx.fillRect(0, 0, canvasSize.width, canvasSize.height);

      // Draw grid
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
      ctx.lineWidth = 1;
      const gridSize = 30;
      for (let x = 0; x < canvasSize.width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvasSize.height);
        ctx.stroke();
      }
      for (let y = 0; y < canvasSize.height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvasSize.width, y);
        ctx.stroke();
      }

      // Draw particles
      particlesRef.current.forEach((p) => {
        const alpha = p.life;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * p.life, 0, Math.PI * 2);
        ctx.fillStyle = p.color.replace(')', `, ${alpha})`).replace('rgb', 'rgba').replace('#', '');
        ctx.fill();
      });

      // Draw food with glow
      foodRef.current.forEach((food) => {
        // Glow effect
        const gradient = ctx.createRadialGradient(
          food.x, food.y, 0,
          food.x, food.y, 20
        );
        gradient.addColorStop(0, food.glowColor + '80');
        gradient.addColorStop(1, 'transparent');
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(food.x, food.y, 20, 0, Math.PI * 2);
        ctx.fill();

        // Food body
        ctx.beginPath();
        ctx.arc(food.x, food.y, 8, 0, Math.PI * 2);
        ctx.fillStyle = food.color;
        ctx.fill();

        // Shine
        ctx.beginPath();
        ctx.arc(food.x - 3, food.y - 3, 3, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
        ctx.fill();
      });

      // Draw snake
      const snakeColor = snakeColorRef.current;
      
      // Draw body segments
      for (let i = snake.length - 1; i >= 0; i--) {
        const segment = snake[i];
        const size = i === 0 ? 14 : 12 - (i * 0.1);
        const actualSize = Math.max(size, 6);
        
        // Segment glow
        const gradient = ctx.createRadialGradient(
          segment.x, segment.y, 0,
          segment.x, segment.y, actualSize * 1.5
        );
        gradient.addColorStop(0, snakeColor.glow + '60');
        gradient.addColorStop(1, 'transparent');
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(segment.x, segment.y, actualSize * 1.5, 0, Math.PI * 2);
        ctx.fill();

        // Segment body
        ctx.beginPath();
        ctx.arc(segment.x, segment.y, actualSize, 0, Math.PI * 2);
        ctx.fillStyle = snakeColor.body;
        ctx.fill();

        // Eyes on head
        if (i === 0) {
          const eyeOffset = 5;
          const eyeSize = 3;
          
          ctx.fillStyle = 'white';
          ctx.beginPath();
          ctx.arc(segment.x + dir.x * eyeOffset - dir.y * eyeOffset, 
                  segment.y + dir.y * eyeOffset + dir.x * eyeOffset, eyeSize, 0, Math.PI * 2);
          ctx.fill();
          
          ctx.beginPath();
          ctx.arc(segment.x + dir.x * eyeOffset + dir.y * eyeOffset, 
                  segment.y + dir.y * eyeOffset - dir.x * eyeOffset, eyeSize, 0, Math.PI * 2);
          ctx.fill();

          // Pupils
          ctx.fillStyle = 'black';
          ctx.beginPath();
          ctx.arc(segment.x + dir.x * (eyeOffset + 1) - dir.y * eyeOffset, 
                  segment.y + dir.y * (eyeOffset + 1) + dir.x * eyeOffset, 1.5, 0, Math.PI * 2);
          ctx.fill();
          
          ctx.beginPath();
          ctx.arc(segment.x + dir.x * (eyeOffset + 1) + dir.y * eyeOffset, 
                  segment.y + dir.y * (eyeOffset + 1) - dir.x * eyeOffset, 1.5, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      animationRef.current = requestAnimationFrame(gameLoop);
    };

    gameLoop();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [showStartScreen, canvasSize, createFood, createParticles]);

  const startGame = () => {
    setShowStartScreen(false);
    initGame();
  };

  return (
    <div className="game-container" ref={gameAreaRef}>
      {/* Score */}
      <div className="score-board">
        <span className="score-label">Pontos:</span>
        <span className="score-value">{score}</span>
      </div>

      {/* Canvas */}
      <canvas
        ref={canvasRef}
        width={canvasSize.width}
        height={canvasSize.height}
        className="game-canvas"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      />

      {/* Start Screen */}
      {showStartScreen && (
        <div className="start-screen">
          <div className="start-content">
            <h1 className="game-title">🐍 Cobrinha Mágica</h1>
            <p className="game-subtitle">Para a princesa mais especial! ✨</p>
            
            <div className="instructions">
              <p>🎮 <strong>Como jogar:</strong></p>
              <p>• Arraste o dedo na tela para mover</p>
              <p>• Ou use as setas do teclado</p>
              <p>• Coma as bolinhas coloridas</p>
              <p>• A cobrinha nunca morre! 💖</p>
            </div>
            
            <button className="start-button" onClick={startGame}>
              🌟 COMEÇAR A DIVERTIR! 🌟
            </button>
          </div>
        </div>
      )}

      {/* Mobile controls hint */}
      {!showStartScreen && (
        <div className="controls-hint">
          👆 Arraste para mover
        </div>
      )}
    </div>
  );
}

export default App;
