# 📱 Como Buildar o APK

## Método 1: GitHub Actions (Recomendado - Mais Fácil)

1. Crie um repositório no GitHub
2. Faça push deste código:
```bash
git init
git add .
git commit -m "Jogo da cobrinha para minha filha"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/cobrinha-filha.git
git push -u origin main
```
3. Vá na aba **Actions** do GitHub
4. O workflow "Build Android APK" vai rodar automaticamente
5. Quando terminar, vá em **Actions > Build Android APK > Último run**
6. Baixe o artifact "cobrinha-debug-apk"

## Método 2: Android Studio

### Pré-requisitos
- [Android Studio](https://developer.android.com/studio) instalado
- Java JDK 17+

### Passos

1. Abra o Android Studio
2. Clique em **Open** e selecione a pasta `android` deste projeto
3. Aguarde o Gradle sincronizar (pode levar alguns minutos)
4. Conecte um celular Android ou use um emulador
5. Clique no botão ▶️ (Run) ou vá em **Build > Build Bundle(s) / APK(s) > Build APK(s)**
6. O APK será salvo em:
   - Debug: `android/app/build/outputs/apk/debug/app-debug.apk`
   - Release: `android/app/build/outputs/apk/release/app-release-unsigned.apk`

## Método 3: Linha de Comando (Linux/Mac)

### Instalar Android SDK

```bash
# Crie uma pasta para o SDK
mkdir -p ~/Android/Sdk
cd ~/Android/Sdk

# Baixe o command line tools
wget https://dl.google.com/android/repository/commandlinetools-linux-9477386_latest.zip
unzip commandlinetools-linux-9477386_latest.zip
mkdir -p cmdline-tools/latest
mv cmdline-tools/* cmdline-tools/latest/ 2>/dev/null || true

# Configure as variáveis de ambiente
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin
export PATH=$PATH:$ANDROID_HOME/platform-tools

# Aceite as licenças
yes | sdkmanager --licenses

# Instale as dependências necessárias
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"
```

### Build o APK

```bash
# No diretório do projeto
cd /mnt/okcomputer/output/app

# Build o app web
npm run build

# Sincronize com Android
npx cap sync android

# Build o APK
cd android
./gradlew assembleDebug

# O APK estará em:
ls -la app/build/outputs/apk/debug/app-debug.apk
```

## 🔧 Solução de Problemas

### Erro: "SDK location not found"
Crie o arquivo `android/local.properties` com:
```
sdk.dir=/caminho/para/seu/Android/Sdk
```

### Erro: "Gradle sync failed"
No Android Studio, vá em **File > Sync Project with Gradle Files**

### Erro: "JAVA_HOME not set"
```bash
export JAVA_HOME=/caminho/para/jdk-17
```

## 📤 Instalar no Celular

1. Copie o APK para o celular (USB, email, WhatsApp, etc.)
2. No celular, vá em **Configurações > Segurança > Fontes desconhecidas** e habilite
3. Toque no arquivo APK para instalar
4. Divirta-se! 🎮
